package com.example.deber3;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.deber3.Modelo.Comida;
import com.example.deber3.Modelo.DataHolder;
import com.example.deber3.Modelo.Gasto;

import java.sql.Date;

public class ComidaActivity extends AppCompatActivity {
    private Button btnAdd;
    private EditText txtDescripcion;
    private EditText txtValor;
    private ListView lvComida;
    private TextView txtTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comida);
        btnAdd = findViewById(R.id.btnAdd);
        txtDescripcion = findViewById(R.id.txtDescripcion);
        txtValor = findViewById(R.id.txtValor);
        txtTotal = findViewById(R.id.txtTotal);
        lvComida = findViewById(R.id.lvSalud);
        final ArrayAdapter<Gasto> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, DataHolder.GetInstance().GetComida());
        lvComida.setAdapter(adapter);
        lvComida.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                final int index = position;
                new AlertDialog.Builder(ComidaActivity.this).setIcon(android.R.drawable.ic_delete)
                        .setTitle("Eliminar elemento")
                        .setMessage("¿Esta seguro de borrar?")
                        .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                DataHolder.GetInstance().DeleteComida(index);
                                adapter.notifyDataSetChanged();
                                txtTotal.setText("Total: " + DataHolder.GetInstance().TotalComida() + "$" );
                            }
                        }).setNegativeButton("No",null).show();
                return true;
            }
        });
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Insert();
            }
        });

    }

    public void Insert(){
        if(txtValor.getText().length()>0 && txtDescripcion.getText().length()>0){
            double valor = Double.parseDouble(String.valueOf(txtValor.getText()));
            String descripcion = String.valueOf(txtDescripcion.getText());
            Gasto gasto = new Comida(valor, descripcion);
            DataHolder.GetInstance().AddComida(gasto);
            txtTotal.setText("Total: " + DataHolder.GetInstance().TotalComida()+ "$");

        }
        else{
            new AlertDialog.Builder(ComidaActivity.this).setIcon(android.R.drawable.stat_notify_error)
                    .setTitle("Error")
                    .setMessage("Verifique que haya datos en los campos")
                    .setPositiveButton("Si", null).show();
        }

    }


}
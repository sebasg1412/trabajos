package com.example.deber3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.example.deber3.Modelo.DataHolder;

public class TotalActivity extends AppCompatActivity {
    private TextView txtTotalComida;
    private TextView txtTotalEducacion;
    private TextView txtTotalSalud;
    private TextView txtTotalGeneral;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_total);
        txtTotalComida = findViewById(R.id.txtTotalComida);
        txtTotalEducacion = findViewById(R.id.txtTotalEducacion);
        txtTotalSalud = findViewById(R.id.txtTotalSalud);
        txtTotalGeneral = findViewById(R.id.txtTotalGeneral);
        txtTotalComida.setText("Total de gastos por comida: "+ DataHolder.GetInstance().TotalComida() + "$");
        txtTotalEducacion.setText("Total de gastos por educación: "+ DataHolder.GetInstance().TotalEducacion() + "$");
        txtTotalSalud.setText("Total de gastos por Salud: "+ DataHolder.GetInstance().TotalSalud() + "$");
        txtTotalGeneral.setText("Total de gastos: "+ DataHolder.GetInstance().TotalGeneral()+ "$");
    }
}
package com.example.deber3.Modelo;

import androidx.annotation.NonNull;

public class Educacion extends Gasto {

    public Educacion(double valor, String descripcion) {
        super(valor, descripcion);
    }

    @NonNull
    @Override
    public String toString() {

        return this.descripcion + " " + this.valor + "$ " + "---" + this.fecha;
    }
}

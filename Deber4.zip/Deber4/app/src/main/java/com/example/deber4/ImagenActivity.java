package com.example.deber4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class ImagenActivity extends AppCompatActivity {

    ImageView imagenG;
    TextView titulo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imagen);
        System.out.println(MainActivity.urlGrande);
        imagenG = findViewById(R.id.imageView);
        titulo = findViewById(R.id.titulo);
        titulo.setText(MainActivity.titulo);
        Picasso.with(getApplicationContext()).load(MainActivity.urlGrande).into(imagenG);

    }
}
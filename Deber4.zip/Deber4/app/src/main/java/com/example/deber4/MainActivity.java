package com.example.deber4;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private Button boton1;
    String url = "https://photojournal.jpl.nasa.gov/gallery/universe";
    String title,link, src, size;
    ArrayList list = new ArrayList();
    ArrayList names = new ArrayList();
    ArrayList links = new ArrayList();
    ArrayList sizes = new ArrayList();
    ProgressDialog pdialog;
    ListView listView1;
    public static String urlGrande = "";
    public static String titulo = "";


    public Bitmap BitmapFromUrl(String url) throws IOException {
        try {
            URL link = new URL(url);
            Bitmap image = BitmapFactory.decodeStream(link.openConnection().getInputStream());
            return image;
        } catch(IOException e) {
            System.out.println(e);
        }
        return null;

    }


    private List<Bitmap> getImages() throws IOException {
        List<Bitmap> imagenes= new ArrayList<Bitmap>();
       for(Object image : list){
           imagenes.add(BitmapFromUrl(image.toString()));
       }
       return imagenes;
    }


    private String saveToInternalStorage(Bitmap bitmapImage, String nombre){
        ContextWrapper cw = new ContextWrapper(getApplicationContext());

        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);

        File mypath=new File(directory, nombre +".jpg");

        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(mypath);

            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return directory.getAbsolutePath();
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        boton1 = findViewById(R.id.btn1);
        listView1 = findViewById(R.id.listView1);


        boton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Content content = new Content();
                content.execute();
            }
        });


    }


    private class Content extends AsyncTask <Void, Void, Void> {

        protected void onPreExecute(){
            super.onPreExecute();
            pdialog = new ProgressDialog(MainActivity.this);
            pdialog.show();
        }

        protected void onPostExecute(Void aVoid){
            super.onPostExecute(aVoid);
            pdialog.dismiss();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            try{
                Document doc = Jsoup.connect(url).get();
                Elements img = doc.select("img[src$=.jpg]");
                for (Element e1 : img){
                    src = e1.absUrl("src");
                    list.add(src);
                }
                Elements nombres = doc.select("dd b:first-child");
                for (Element e1 : nombres){
                    title = e1.ownText();
                    names.add(title);
                   // System.out.println(title);
                }
                Elements urls = doc.select("dd a:nth-child(6)");
                for (Element e1 : urls){
                    link = e1.absUrl("href");
                    links.add(link);
                    System.out.println(link);
                }
                Elements tams = doc.select("dd font:nth-child(7)");
                for (Element e1 : tams){
                    size = e1.ownText();
                    sizes.add(size);
                   // System.out.println(size);
                }

                Log.d("images links", list.toString());
                List<Bitmap> imgs = getImages();
                List<String> uris = new ArrayList<>();
                for (int i = 0; i < imgs.size(); i++){
                    uris.add(saveToInternalStorage(imgs.get(i),""+ i)+"/"+i+".jpg");
                }

                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {

                        List<HashMap<String,Object>> aList = new ArrayList<HashMap<String,Object>>();
                        for(int i=0;i<list.size()-1;i++){
                            HashMap<String, Object> hm = new HashMap<String,Object>();
                            hm.put("flag", uris.get(i));
                            hm.put("txt", names.get(i));
                            hm.put("cur", sizes.get(i));
                            hm.put("li",links.get(i));
                            aList.add(hm);
                        }

                        String[] from = { "flag","txt","cur","li" };

                        int[] to = { R.id.flag,R.id.txt,R.id.cur,R.id.li};

                        SimpleAdapter adapter = new SimpleAdapter(getBaseContext(), aList, R.layout.custom_item, from, to);
                        listView1.setAdapter(adapter);
                        listView1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                            @Override
                            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                                final int which_item = position;
                                new AlertDialog.Builder(MainActivity.this).setIcon(android.R.drawable.star_on)
                                        .setTitle("Abrir?")
                                        .setMessage("esta seguro?")
                                        .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                urlGrande = links.get(which_item).toString();
                                                titulo = (String) names.get(which_item);
                                                System.out.println(urlGrande);
                                                Intent imagen =  new Intent(view.getContext(), ImagenActivity.class);
                                                imagen.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                                view.getContext().startActivity(imagen);

                                                adapter.notifyDataSetChanged();
                                            }
                                        }).setNegativeButton("No", null).show();
                                return true;
                            }
                        });


                    }
                });




            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

    }

    @Override
    protected void onDestroy(){
        OcultarDialogo();
        super.onDestroy();
    }

    private void OcultarDialogo(){
        if(pdialog != null && pdialog.isShowing()){
            pdialog.dismiss();
        }
    }

}
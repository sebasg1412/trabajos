package com.example.deber3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.deber3.Modelo.DataHolder;
import com.example.deber3.Modelo.Gasto;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private Button btnComida;
    private Button btnEducacion;
    private Button btnSalud;
    private Button btnTotal;
    private List<Gasto> comida;
    private List<Gasto> educacion;
    private List<Gasto> salud;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnComida = findViewById(R.id.btnComida);
        btnEducacion = findViewById(R.id.btnEducacion);
        btnSalud = findViewById(R.id.btnSalud);
        btnTotal = findViewById(R.id.btnTotal);
        comida = new ArrayList();
        educacion = new ArrayList();
        salud = new ArrayList();
        DataHolder.GetInstance().SetComida(comida);
        DataHolder.GetInstance().SetEducacion(educacion);
        DataHolder.GetInstance().SetSalud(salud);

    }

    public void Comida(View view){
        Intent comida = new Intent(this,ComidaActivity.class);
        startActivity(comida);
    }

    public void Educacion(View view){
        Intent educacion = new Intent(this,EducacionActivity.class);
        startActivity(educacion);
    }
    public void Salud(View view){
        Intent salud = new Intent(this,SaludActivity.class);
        startActivity(salud);
    }
    public void Total(View view){
        Intent total = new Intent(this,TotalActivity.class);
        startActivity(total);
    }
}
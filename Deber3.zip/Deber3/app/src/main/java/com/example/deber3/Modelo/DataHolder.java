package com.example.deber3.Modelo;

import java.util.List;

public class DataHolder {

    private List<Gasto> comida;
    private List<Gasto> educacion;
    private List<Gasto> salud;

    public List<Gasto> GetComida (){

        return comida;
    }
    public List<Gasto> GetEducacion (){

        return educacion;
    }
    public List<Gasto> GetSalud (){

        return salud;
    }

    public void SetComida(List<Gasto> comida){

        this.comida = comida;
    }

    public void SetEducacion(List<Gasto> educacion){

        this.educacion = educacion;
    }

    public void SetSalud(List<Gasto> salud){

        this.salud = salud;
    }

    private static final DataHolder holder = new DataHolder();

    public static DataHolder GetInstance(){

        return holder;
    }

    public void DeleteComida(int index){

        comida.remove(index);
    }
    public void DeleteEducacion(int index){

        educacion.remove(index);
    }
    public void DeleteSalud(int index){

        salud.remove(index);
    }
    public void AddComida(Gasto gasto){

        comida.add(gasto);
    }
    public void AddEducacion(Gasto gasto){

        educacion.add(gasto);
    }
    public void AddSalud(Gasto gasto){

        salud.add(gasto);
    }

    public double TotalComida(){
        double total = 0;
        for (Gasto elemento: comida) {
            total += elemento.valor;
        }
        return total;
    }
    public double TotalEducacion(){
        double total = 0;
        for (Gasto elemento: educacion) {
            total += elemento.valor;
        }
        return total;
    }

    public double TotalSalud(){
        double total = 0;
        for (Gasto elemento: salud) {
            total += elemento.valor;
        }
        return total;
    }

    public double TotalGeneral(){

        return TotalComida()+TotalEducacion()+TotalSalud();
    }



}

package com.example.deber3.Modelo;

import java.util.Date;

public class Gasto {
    public double valor;
    public String descripcion;
    public Date fecha;

    public Gasto (double valor, String descripcion){
        this.valor = valor;
        this.descripcion = descripcion;
        this.fecha = new Date();
    }


}
